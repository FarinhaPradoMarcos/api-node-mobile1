const Carro = require('../models/carro');

class CarroRepository{
    async createcarro(carro){
        return await Carro.create(carro);
    }

    async findBycarroName(modelo){
        return await Carro.findOne({where: {modelo}})
    }

    async findAll(){
        return await Carro.findAll();
    }
}

module.exports = new CarroRepository();
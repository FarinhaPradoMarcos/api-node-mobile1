const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const  carro = sequelize.define('carro', {
    id: {
        type: DataTypes.UUIDV4,
        primaryKey: true
    },
    modelo: {
        type: DataTypes.STRING(),
        validate: {
            len: [2, 50]
        },
        allowNull: false
    },
    ano: {
        type: DataTypes.DECIMAL(4),
        allowNull: false
    },
    dsc: {
        type: DataTypes.STRING,
        validate: {
            len: [10, 500]
        },
        allowNull: false
    },
    preco: {
        type: DataTypes.DECIMAL(50, 2),
        allowNull: false
    }

})

module.exports = carro;
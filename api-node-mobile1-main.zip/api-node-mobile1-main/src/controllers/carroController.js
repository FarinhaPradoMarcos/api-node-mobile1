const express = require('express');
const carroService = require('../services/carroService');
const authenticateToken = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res) =>{
    try{
        const carros = await carroService.getcarro();//pode ser maiusculo ou min
        res.json(carros);
    }
    catch(error){
        res.status(400).json({error: error.message});
    }
})

router.post('/', authenticateToken, async(req,res) =>{
    try{

    const { modelo, ano, dsc, preco } = req.body;
    const carro = await carroService.register(modelo, ano, dsc, preco);
    res.status(201).json(carro);
}
catch(error){
    res.status(400).json({error: error.message});
}
})


module.exports = router;
const bcrypt = require('bcrypt');
const carroRepository = require('../repositories/carroRepository');
const { v4: UUIDV4 } = require('uuid');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'SUACHAVESECRETA';

class carroService{
    async register(modelo, ano, dsc, preco){
        const getcarro = await this.getBycarroName(modelo);
        console.log(getcarro);
        if(getcarro){
            throw new Error('carro já cadastrado');
        }
        const carro = await carroRepository.createcarro({id: UUIDV4(), modelo, ano, dsc, preco});
        return carro;

    }

    async getBycarroName(carro){
        return await carroRepository.findBycarroName(carro);
    }



    async getcarro(){
        return await carroRepository.findAll();
    }
}

module.exports = new carroService();
const express = require('express');
const UserService = require('../services/userService');

const router = express.Router();

router.get('/', async (req, res) =>{
    try{
        const user = await UserService.getUser();
        res.json(users);
        } 
        catch (error) {
            res.status(400).json({error: error.message});
     }
})
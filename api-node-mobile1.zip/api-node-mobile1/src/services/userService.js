const bcrypt = require('bcrypt');
const UserRepository = require('../repositories/userRepository');
const userRepository = require('../repositories/userRepository');

const SECRET_KEY = 'https://www.instagram.com/marcos_farinha_prado/ ZJVCHVJZD BCDNVJ HZBXNBJHJZNVJHJ';

class UserService{
    async register(username, password, email){
        if(this.getByUserName(username)){
            throw new Error('ja tem essa merda ai bro')
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await userRepository.createUser({username, email, password: hashedPassword});
        return user;

    }

    async getByUserName(username){
        return await userRepository.findByUserName(username);
    }

    async login(username, password){
        const user = this.getByUserName(username);
        if(!user){
            throw new Error('usuario ou senha ñ tem');
        }

        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const isPasswordValid = await bcrypt.compare(hashedPassword, user.password);
        if(!isPasswordValid){
            throw new Error('usuario ou senha ñ tem');
        }
        return true;
   }
   async getUsers(){
    return await userRepository.findall();
   }
}

module.exports = new UserService();
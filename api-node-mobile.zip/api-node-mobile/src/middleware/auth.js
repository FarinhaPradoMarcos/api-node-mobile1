const jwt = require('jsonwebtoken');
const SECRET_KEY = 'AMOFEMBOYS';

function authenticateToken(req, res, next){
    const authHeader = req.headers['authorization'];
    console.log(authHeader);

    if(!authHeader){
        return res.sendStatus(401);
    }

    jwt.verify(authHeader, SECRET_KEY, (err, user) => {
    if(err) {
        return res.sendStatus(403);
    }

    next();
    })
}

module.exports = authenticateToken;